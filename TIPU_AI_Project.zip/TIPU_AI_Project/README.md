# TIPU-AI Android Project

This is an initial Android source project foundation plus the complete master specification.
It is **not** a finished implementation of every requested feature and is not a prebuilt APK.

## Included
- Kotlin Android app foundation
- Hindi-first screen with manual listen/stop controls
- Speech-to-text using Android SpeechRecognizer (device/service support required)
- Text-to-speech replies
- Basic intents to open supported apps, Maps, dialer, and alarm screen
- GitHub Actions workflow to build a debug APK
- Complete TIPU feature specification

## Not yet implemented
Wake-word engine, continuous/background listening, voice biometrics, trusted-device backend,
full offline conversational model, autonomous learning/retraining, and unrestricted WhatsApp/
Instagram messaging or call controls. These need separate implementation, platform permissions,
official integrations, backend services, and device testing.

## Build
Open this folder as an Android project in Android Studio, or push the repository contents to
GitHub and use the included Actions workflow. A successful build still needs testing on a real phone.

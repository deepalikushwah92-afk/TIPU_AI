# TIPU – My Personal Smart AI Voice Assistant
## Master Product Specification

**Project name:** TIPU-AI  
**Platform:** Android  
**Primary language:** Hindi, with support for English commands  
**Modes:** Online AI + Offline basic commands

This document is the master specification for the TIPU Android app. It describes the intended features and implementation requirements. It is not a completed APK, and features must be implemented and tested in stages.

## 1. Main assistant experience
- Hindi voice input and spoken Hindi responses.
- Text chat fallback when voice is unavailable.
- A clear manual microphone button.
- Listening, thinking, and speaking status indicators.
- After a command finishes, wait about 4 seconds and then offer/listen again while Listening Mode is enabled.
- Listening Mode must be manually started and stopped.
- Listening Mode must not automatically start after a phone restart.

## 2. Wake word and voice identity
- Target wake phrase: “Hey TIPU”.
- Wake-word detection should be designed for low battery use and require clear user consent.
- Optional voice identity verification to distinguish the enrolled user's voice.
- Voice matching must be treated as a convenience signal, not the only security lock.
- Provide a way to re-enrol or disable voice recognition.
- Explain microphone permissions and show a visible listening indicator.

## 3. Android phone actions
Where Android permissions and supported intents allow:
- Open installed apps by name.
- Find a contact and ask for confirmation before placing a call.
- Open the phone dialer with a selected number.
- Open YouTube or a selected music/video app.
- Open Google Maps and pass a destination or route query.
- Create alarms and reminders using supported Android APIs/intents.
- Read back the action before performing sensitive actions.

## 4. Messaging and social apps
- Prepare WhatsApp messages from voice dictation.
- Open the relevant WhatsApp chat or share/compose screen where supported.
- Let the user review and confirm before sending.
- Support WhatsApp Business handoff where the installed app supports it.
- Instagram message assistance should use supported sharing/deep-link flows only.
- Do not promise unrestricted reading, sending, or automation inside third-party apps.
- Incoming call controls depend on Android version, app permissions, and the third-party app's supported integration.

## 5. Online knowledge and learning
- Search the web/approved knowledge sources when online.
- Prefer reliable sources and show source names/links with factual answers.
- Compare sources when information conflicts.
- Display when information is uncertain, old, or unverified.
- Maintain an optional local knowledge base of user-approved notes and useful facts.
- Ask permission before saving personal preferences or private information.
- Provide controls to view, edit, export, and clear saved knowledge.
- Do not claim that TIPU changes or retrains its underlying AI model merely by browsing. It can retrieve information and update its own knowledge base.

## 6. Offline mode
- Basic offline commands should work without internet, such as opening supported apps, telling time, and launching alarms where Android permits.
- Clearly show whether the assistant is Online or Offline.
- Queue non-sensitive requests only if the user explicitly enables that behavior.
- Cloud conversational AI and web search require internet.
- A large, fully conversational offline AI model is not guaranteed on every phone; device capability and model size must be evaluated separately.

## 7. Security and privacy
- Optional app PIN/password and Android biometric prompt (fingerprint where available).
- Request only permissions needed for enabled features.
- Explain why microphone, contacts, notifications, or other permissions are requested.
- Optional trusted-device list and login history if a secure account/backend is implemented.
- New-device approval and notifications require a backend and a verified account/device identity.
- Provide sign-out and revoke-device controls.
- Protect stored tokens and private data using Android's secure storage facilities.
- Never store raw voice recordings by default; obtain clear consent for any voice enrolment data.

## 8. User interface
- No human face or mouth.
- Central glowing 3D-style AI orb.
- Idle state: gentle floating/glow animation.
- Listening state: pulsing light/ring.
- Thinking state: rotating or moving light.
- Speaking state: animated sound-wave/glow effect.
- Large, readable controls suitable for a phone screen.
- Hindi-first labels and clear permission/status messages.
- Accessibility support, including readable contrast and touch targets.

## 9. Suggested technical architecture
- Native Android application using Kotlin.
- Android SpeechRecognizer for speech input where available.
- Android TextToSpeech for spoken responses.
- Android intents and supported Android APIs for phone actions.
- Local database for settings, reminders, and user-approved knowledge.
- Optional secure backend for online AI, account sync, and trusted-device management.
- A source/retrieval layer for web knowledge that records source links and retrieval dates.
- Keep API keys on a secure backend; do not embed secret keys in the APK or public repository.
- Use GitHub Actions or another Android build service to build APKs from source.

## 10. Permissions and platform limitations
- Microphone, contacts, notifications, alarms, and other permissions must be requested only when needed.
- Background microphone use and wake-word operation are restricted by Android policies and battery-management behavior.
- Third-party apps control what external apps allow; TIPU cannot bypass their security or privacy controls.
- WhatsApp/Instagram direct messaging and call controls are limited to officially supported integrations and user-confirmed handoffs.
- Fingerprint authentication must use Android's biometric APIs; TIPU must not collect fingerprint data itself.

## 11. Development milestones
1. Create the native Android project, app theme, orb screen, and settings.
2. Add Hindi speech input/output and manual Listening Mode.
3. Add safe Android actions: app launch, dialer, Maps, alarms, and reminders.
4. Add online AI backend and sourced web knowledge.
5. Add offline basic commands and local knowledge storage.
6. Add optional PIN/biometric protection and privacy controls.
7. Evaluate wake-word feasibility and battery impact on target devices.
8. Add secure account/trusted-device features if backend infrastructure is available.
9. Add supported messaging handoffs.
10. Build, install, and test on real Android devices; document unsupported features.

## 12. Definition of done
A feature is complete only after its code is present, required permissions are documented, errors are handled, and it has been tested on a real supported Android device. A specification or placeholder screen alone does not count as an implemented feature.

---
**Important:** This file records the complete requested product scope. It does not claim that every feature has already been coded, built, or tested.

package com.tipu.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF080D1C.toInt())
        }
        val title = TextView(this).apply {
            text = "TIPU"
            textSize = 38f
            setTextColor(0xFF8BE9FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "नमस्ते! मैं TIPU हूँ।"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        val listen = Button(this).apply {
            text = "🎙 बोलने के लिए दबाएँ"
            setOnClickListener { startListening() }
        }
        val stop = Button(this).apply {
            text = "Listening बंद करें"
            setOnClickListener {
                speech?.cancel()
                status.text = "Listening बंद है"
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(listen)
        layout.addView(stop)
        setContentView(layout)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "इस फोन पर Speech Recognition उपलब्ध नहीं है।"
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "सुन रहा हूँ..." }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                status.text = if (text.isBlank()) "कुछ सुनाई नहीं दिया" else "आपने कहा: $text"
                handleCommand(text)
            }
            override fun onError(error: Int) { status.text = "आवाज़ समझ नहीं आई। फिर कोशिश करें।" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        speech?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        val c = command.lowercase(Locale.ROOT)
        val reply = when {
            c.contains("व्हाट्सएप") || c.contains("whatsapp") -> openPackage("com.whatsapp", "WhatsApp खोल रहा हूँ।")
            c.contains("इंस्टाग्राम") || c.contains("instagram") -> openPackage("com.instagram.android", "Instagram खोल रहा हूँ।")
            c.contains("यूट्यूब") || c.contains("youtube") -> openPackage("com.google.android.youtube", "YouTube खोल रहा हूँ।")
            c.contains("मैप") || c.contains("रास्ता") || c.contains("maps") -> {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=")))
                "Maps खोल रहा हूँ।"
            }
            c.contains("अलार्म") || c.contains("alarm") -> {
                startActivity(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS))
                "अलार्म खोल रहा हूँ।"
            }
            c.contains("समय") || c.contains("टाइम") || c.contains("time") -> {
                "अभी समय ${java.text.SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(java.util.Date())} है।"
            }
            else -> "मैंने सुना: $command। इस कमांड को अभी जोड़ना बाकी है।"
        }
        status.text = reply
        if (::tts.isInitialized) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "tipu-reply")
    }

    private fun openPackage(packageName: String, reply: String): String {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch) else status.text = "यह ऐप फोन में इंस्टॉल नहीं है।"
        return reply
    }

    override fun onDestroy() {
        speech?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
